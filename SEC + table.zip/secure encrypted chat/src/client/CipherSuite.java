package client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.bouncycastle.jcajce.provider.symmetric.AES;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author popo
 */
public class CipherSuite {
//    RSA init variables
    private KeyPairGenerator keyGen;
    private KeyPair keyPair;
    private PrivateKey privateKey;
    private PublicKey publicKey;
    private Cipher cipher;
    private byte[] bufferByte;
    private int keysize = 1024;
    

    
    
    public  void Functions() {
        
    }
    public  void initializeRSA() {
        try {
            Security.addProvider(new BouncyCastleProvider());
            keyGen = KeyPairGenerator.getInstance("RSA","BC");
            keyGen.initialize(keysize);
            keyPair = keyGen.generateKeyPair();
            privateKey = keyPair.getPrivate();
            publicKey = keyPair.getPublic();
            cipher = Cipher.getInstance("RSA", "BC");
        } catch (Exception e) {
//            System.out.println(e.toString());
//            Logger.getLogger(CryptoTEST.class.getName()).log(Level.SEVERE, "conctructor error : "+e);
        }
    }
    
    
    public String encrypt(String plainText,PublicKey publicKey) throws Exception{
        
                byte[] plainTextByte = plainText.getBytes();
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;
                
        
    }
    
    public  String Decipher(String ciphertext,PrivateKey privateKey)throws Exception {
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(ciphertext);
                cipher.init(Cipher.DECRYPT_MODE, privateKey);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);
		return decryptedText;
	}
    
//     public byte[] encrypt(byte[] message,PublicKey publicKey){
//        try {
//            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
//            bufferByte = cipher.doFinal(message);
//            
//            return bufferByte;
//            
//        } catch (Exception e) {
//             
////            Logger.getLogger(CryptoTEST.class.getName()).log(Level.SEVERE, "encryption error : "+e);
//              return null;
//        }
//    }
//    
//    public  byte[] Decipher(byte[] ciphertext,PrivateKey privateKey){
//        try {
//            cipher.init(Cipher.DECRYPT_MODE, privateKey);
//            byte[] bufferByteDecrypt = cipher.doFinal(ciphertext);
//            return bufferByteDecrypt;
//        } catch (Exception ex) {
////            Logger.getLogger(CryptoTEST.class.getName()).log(Level.SEVERE, "Decryptor error : "+ ex);
//               return null;
//        }
//    }
    
    public void saveKeys(String path, KeyPair keyPair) throws FileNotFoundException, IOException{
              PrivateKey privateKey = keyPair.getPrivate();
	      PublicKey publicKey = keyPair.getPublic();
              byte[] privateKeyBytes = privateKey.getEncoded();
              byte[] publicKeyBytes = publicKey.getEncoded();
              FileOutputStream foutPriv = new FileOutputStream(path +"/private.key");
              FileOutputStream foutPub = new FileOutputStream(path +"/public.key");
              foutPriv.write(privateKeyBytes);
              foutPriv.close();
              foutPub.write(publicKeyBytes);
              foutPub.close();
      }
    public KeyPair LoadKeyPair(String path, String algorithm)
			throws IOException, NoSuchAlgorithmException,
			InvalidKeySpecException {
		// Read Public Key.
		File filePublicKey = new File(path + "/public.key");
		FileInputStream fis = new FileInputStream(path + "/public.key");
		byte[] encodedPublicKey = new byte[(int) filePublicKey.length()];
		fis.read(encodedPublicKey);
		fis.close();

		// Read Private Key.
		File filePrivateKey = new File(path + "/private.key");
		fis = new FileInputStream(path + "/private.key");
		byte[] encodedPrivateKey = new byte[(int) filePrivateKey.length()];
		fis.read(encodedPrivateKey);
		fis.close();

		// Generate KeyPair.
		KeyFactory keyFactory = KeyFactory.getInstance(algorithm);
		X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(
				encodedPublicKey);
		PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);

		PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(
				encodedPrivateKey);
		PrivateKey privateKey = keyFactory.generatePrivate(privateKeySpec);
                
//                assign to original keys
                this.privateKey = privateKey;
                this.publicKey  = publicKey;
                
		return new KeyPair(publicKey, privateKey);
	}
    
    public KeyPair getkeyPair(){
     return keyPair;
    } 
    public PrivateKey getPrivateKey(){
     return privateKey;
    } 
    public PublicKey getPublicKey(){
     return publicKey;
    } 
    
    
    //    AES init variables
    private Cipher cipherAES;
    private  SecretKey  keyAES = null;
    byte[] ivBytes = new byte[] { 0x00, 0x01, 0x02, 0x03, 0x00, 0x01, 0x02, 0x03, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x01 };
    
    public void initialiseAES(){
        try{
//           cipherAES = Cipher.getInstance("AES");
          
           KeyGenerator keyGenAES;
           keyGenAES = KeyGenerator.getInstance("AES");
           keyGenAES.init(new SecureRandom());
           keyAES = keyGenAES.generateKey();
           
        }catch (Exception e) {
            System.out.println(e.toString());
//            Logger.getLogger(CryptoTEST.class.getName()).log(Level.SEVERE, "conctructor error : "+e);
        }
    }
//    public byte[] encryptAES(byte[] input,SecretKey k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
//        Cipher cipher  = Cipher.getInstance("AES");
//        cipher.init(Cipher.ENCRYPT_MODE, k);
//        byte[] result = cipher.doFinal(input);
//        return result;
//    }
//    public byte[] decryptAES(byte[] input,SecretKey k) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
//        Cipher cipher  = Cipher.getInstance("AES");
//        cipher.init(Cipher.DECRYPT_MODE, k);
//        byte[] result = cipher.doFinal(input);
//        return result;
//    }
    public  String encryptAES(String plainText, SecretKey secretKey)
			throws Exception {
		byte[] plainTextByte = plainText.getBytes();
                Cipher cipher  = Cipher.getInstance("AES/CTR/NoPadding","BC");
                IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey,ivSpec);
		byte[] encryptedByte = cipher.doFinal(plainTextByte);
		Base64.Encoder encoder = Base64.getEncoder();
		String encryptedText = encoder.encodeToString(encryptedByte);
		return encryptedText;
	}

	public  String decryptAES(String encryptedText, SecretKey secretKey)
			throws Exception {
		Base64.Decoder decoder = Base64.getDecoder();
		byte[] encryptedTextByte = decoder.decode(encryptedText);
                 IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
                Cipher cipher  = Cipher.getInstance("AES/CTR/NoPadding","BC");
		cipher.init(Cipher.DECRYPT_MODE, secretKey,ivSpec);
		byte[] decryptedByte = cipher.doFinal(encryptedTextByte);
		String decryptedText = new String(decryptedByte);
		return decryptedText;
	}
    public SecretKey getKeyAES(){
      return keyAES;
    }
    public byte[] EncryptSecretKey (SecretKey skey,PublicKey pkey)
{
    Cipher cipher = null;
    byte[] key = null;

    try
    {
        // initialize the cipher with the user's public key
        cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, pkey);
        key = cipher.doFinal(skey.getEncoded());
    }
    catch(Exception e )
    {
        System.out.println ( "exception encoding key: " + e.getMessage() );
        e.printStackTrace();
    }
    return key;
}
    public SecretKey decryptAESKey(byte[] data ,PrivateKey privKey)
    {
        SecretKey key = null;
       
        Cipher cipher = null;

        try
        {
            // this is OUR private key
           

            // initialize the cipher...
            cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privKey );

            // generate the aes key!
            key = new SecretKeySpec ( cipher.doFinal(data), "AES" );
        }
        catch(Exception e)
        {
            System.out.println ( "exception decrypting the aes key: " 
                                                   + e.getMessage() );
            return null;
        }

        return key;
    }
}
