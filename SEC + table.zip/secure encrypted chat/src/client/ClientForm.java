/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigInteger;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 *
 * @author popo
 */
public class ClientForm extends javax.swing.JFrame {

//    crypto variables
   
    private static String chatWith;
    public static  Connection conn = null;
    private static  String text = null;
    //    crypto variable declaration
    private PublicKey otherPubKey = null;
    private SecretKey  deAESkey = null;
    
   
    
   
 
    
   
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        chatWindow = new javax.swing.JTextArea();
        sendBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        userText = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        portInput = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        muteTone = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(200, 485));
        setPreferredSize(new java.awt.Dimension(323, 540));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        chatWindow.setColumns(20);
        chatWindow.setFont(new java.awt.Font("Times New Roman", 0, 13)); // NOI18N
        chatWindow.setRows(5);
        jScrollPane1.setViewportView(chatWindow);
        chatWindow.getAccessibleContext().setAccessibleDescription("");

        sendBtn.setText("Send");
        sendBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendBtnActionPerformed(evt);
            }
        });

        userText.setColumns(20);
        userText.setRows(5);
        jScrollPane2.setViewportView(userText);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setLayout(new java.awt.BorderLayout());

        jLabel1.setText("Port");

        muteTone.setText("Mute");

        jLabel2.setText("Login as : ");

        jLabel3.setText("jLabel3");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(portInput, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(muteTone))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(sendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(244, 244, 244)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(182, 182, 182))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1)
                        .addComponent(portInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(muteTone, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sendBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sendBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sendBtnActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        closeCrap();
    }//GEN-LAST:event_formWindowClosed

    /**
     * @param args the command line arguments
     */
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea chatWindow;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton muteTone;
    private javax.swing.JTextField portInput;
    private javax.swing.JButton sendBtn;
    private javax.swing.JTextArea userText;
    // End of variables declaration//GEN-END:variables
    
    private String message = "";
    private String serverIP;
    private String chatPort;
    private Socket connection;
    private ObjectOutputStream output;
    private ObjectInputStream input;

    
    public ClientForm(Connection con,String server,String port,String user,String chatwit) {
        
        super("C Messenger");
        
        
        
        initComponents();
        conn = con;
        serverIP = server;
        chatWith = chatwit;
        chatPort = port;
        jLabel3.setText(user);
        portInput.setText(chatPort);
        chatWindow.setMargin(new Insets(5, 5, 5, 5));
        userText.setLineWrap(true);
        chatWindow.setLineWrap(true);
        userText.setMargin(new Insets(2, 2, 2, 2));

        chatWindow.setEditable(false);
        userText.setEditable(false);

        sendBtn.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent event) {
                Date dNow = new Date();
               text = userText.getText();
                SimpleDateFormat ft = new SimpleDateFormat("MMM d',' yyyy 'at' hh:mm:ss a");

                try {
                    //                sendMessage(text + "\n\t" + ft.format(dNow));
                    
                    String encmsg = UserList.funcObj.encryptAES(text, deAESkey);
                    sendMessage(encmsg);
                    UserList.log.logEvent("message sent\t"+encmsg);
                } catch (Exception ex) {
                    Logger.getLogger(ClientForm.class.getName()).log(Level.SEVERE, null, ex);
                }

                userText.setText("");
            }
        });

    }

    public void startRunning() throws ClassNotFoundException {
//        connectBtn.setEnabled(false);
        try {
            connectToServer();

            setupStreams();
            
            whileChatting();

        } catch (EOFException eofException) {
            showSystemMessage("\n"+chatWith+"  terminated the connection ");
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }finally {
//            closeCrap();
        }

    }
  
    private void connectToServer() throws IOException {
        UserList.log.logEvent("Attempting connection . . . .");
        connection = new Socket(InetAddress.getByName(serverIP), Integer.parseInt(portInput.getText()));
        UserList.log.logEvent("connected to " + connection.getInetAddress().getHostAddress());

    }
    
    Base64.Encoder encoder = Base64.getEncoder();
    
    private void setupStreams() throws IOException {
        output = new ObjectOutputStream(connection.getOutputStream());
        output.flush();
        input = new ObjectInputStream(connection.getInputStream());
        UserList.log.logEvent("streams are now setup. . . .");
       
        try {
//            Receive Server public Key
            Object otherKey = input.readObject();
            otherPubKey = (PublicKey) otherKey;
            byte[] otherPubKeyArray = otherPubKey.getEncoded();
            UserList.log.logEvent("server public key received \n\t\t\t"+encoder.encodeToString(otherPubKeyArray)+"\n");
//            Send client public Key
            output.writeObject(UserList.funcObj.getPublicKey());
            output.flush();
            byte[] pubkArray = UserList.funcObj.getPublicKey().getEncoded();
            UserList.log.logEvent("client public key sent \n\t\t\t"+encoder.encodeToString(pubkArray)+"\n");
             
//            success
//            JOptionPane.showMessageDialog(this, "Server pubKey : \n "+otherPubKey);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ServerForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       try{
            byte[] enAESkey =(byte[]) input.readObject();
            UserList.log.logEvent("encrypted AES key received \n\t"+encoder.encodeToString(enAESkey)+"\n");
            
             deAESkey = UserList.funcObj.decryptAESKey(enAESkey, UserList.funcObj.getPrivateKey());
             byte[] aesKeyArray = deAESkey.getEncoded();
              UserList.log.logEvent(" AES key decrypted \n\t"+encoder.encodeToString(aesKeyArray));
         } catch(IOException e){
//               JOptionPane.showMessageDialog(this, "Error receiving hello");
         } catch(ClassNotFoundException e){
               e.printStackTrace();
         } catch (Exception ex) {
            Logger.getLogger(ClientForm.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }

    private void whileChatting() throws IOException {

       
        ableToType(true);
        int f = 0;
         do {
            System.out.println("Do");
            try {
                message = (String) input.readObject();
                UserList.log.logEvent("message received\t"+message);
                try {
                    message = UserList.funcObj.decryptAES(message, deAESkey);
                    UserList.log.logEvent("message decrypted\t"+message);
                } catch (Exception ex) {
                    Logger.getLogger(ClientForm.class.getName()).log(Level.SEVERE, null, ex);
                }

                            showMessage(chatWith + " - " + message);
                            if (!muteTone.isSelected()) {
                                String pop = "res/received.wav";
                                playSound(pop);
                            }
            } catch (ClassNotFoundException e) {
                showMessage("\n ");
            }
        } while (!message.equals("SERVER - END"));
    }

    private void closeCrap() {

//        connectBtn.setEnabled(true);
        showSystemMessage(" Closing connections...");
        ableToType(false);
        try {
            output.close();
            input.close();
            connection.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(String message) {
        try {
            if (!text.isEmpty()) {
                output.writeObject(message);
                output.flush();
                showMessage("You - " + text);

                if (!muteTone.isSelected()) {
                    String pop = "res/sent.wav";
                    playSound(pop);
                }
            }
        } catch (IOException e) {
            chatWindow.append("\n Error : can't send   that message");

        }
    }

    private void showMessage(final String text) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                chatWindow.append(text.trim() + "\n");
            }
        });
    }

    private void showSystemMessage(final String texts) {

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JLabel jlabel = new JLabel(texts.trim());
                java.awt.Font theFont = new java.awt.Font("Helvetica", Font.BOLD, 10);
                jlabel.setFont(theFont);

                chatWindow.append(texts.trim() + "\n");
            }
        });
    }

    private void ableToType(final boolean b) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                userText.setEditable(b);
            }
        });
    }

    private void playSound(String pop) {
        try {

            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(this.getClass().getResource(pop)));
            clip.start();
//            Thread.sleep(clip.getMicrosecondLength() / 1000);
        } catch (Exception e) {
            // a special way i'm handling logging in this application
            JOptionPane.showMessageDialog(this, " not right");
        }
    }
    
   

}
